"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Upload, X, Play } from "lucide-react"
import { generateNumberImage } from "@/utils/number-images"

interface ImageUploaderProps {
  onImagesSelected: (images: string[]) => void
  onStart: () => void
  uploadedImages: string[]
}

export function ImageUploader({ onImagesSelected, onStart, uploadedImages }: ImageUploaderProps) {
  const [images, setImages] = useState<string[]>(uploadedImages)
  const [isProcessing, setIsProcessing] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const maxImages = 11 // 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files) return

    setIsProcessing(true)
    const newImages = [...images]
    const remainingSlots = maxImages - newImages.length
    let filesProcessed = 0
    const totalFiles = Math.min(files.length, remainingSlots)

    Array.from(files)
      .slice(0, remainingSlots)
      .forEach((file) => {
        const reader = new FileReader()
        reader.onload = (event) => {
          if (event.target?.result) {
            newImages.push(event.target.result as string)
            filesProcessed++

            if (filesProcessed === totalFiles) {
              setImages([...newImages])
              onImagesSelected([...newImages])
              setIsProcessing(false)
            }
          }
        }
        reader.onerror = () => {
          filesProcessed++
          if (filesProcessed === totalFiles) {
            setIsProcessing(false)
          }
        }
        reader.readAsDataURL(file)
      })
  }

  const handleRemoveImage = (index: number) => {
    const newImages = [...images]
    newImages.splice(index, 1)
    setImages(newImages)
    onImagesSelected(newImages)
  }

  const handleUploadClick = () => {
    fileInputRef.current?.click()
  }

  const getNumberForIndex = (index: number): number => {
    return Math.pow(2, index + 1) // 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048
  }

  return (
    <div className="w-full max-w-3xl">
      <h2 className="text-2xl font-semibold mb-4 text-center">上传自定义方块图片</h2>
      <p className="text-center text-muted-foreground mb-6">
        上传最多11张图片来代表从2到2048的数字。缺少的图片将使用默认数字方块。
      </p>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 mb-6">
        {/* 显示已上传的图片 */}
        {images.map((image, index) => (
          <div key={index} className="relative">
            <div className="aspect-square relative">
              <div className="absolute inset-0 flex items-center justify-center bg-white rounded-md overflow-hidden border">
                <img
                  src={image || "/placeholder.svg"}
                  alt={`方块 ${getNumberForIndex(index)}`}
                  className="w-full h-full object-contain"
                />
              </div>
              <div className="absolute bottom-0 left-0 right-0 bg-background/80 text-center py-1">
                {getNumberForIndex(index)}
              </div>
              <button
                className="absolute top-2 right-2 bg-background/80 rounded-full p-1 hover:bg-background"
                onClick={() => handleRemoveImage(index)}
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          </div>
        ))}

        {/* 为剩余槽位上传按钮 */}
        {images.length < maxImages && (
          <Card
            className="aspect-square cursor-pointer hover:bg-muted/50 transition-colors flex items-center justify-center"
            onClick={handleUploadClick}
          >
            <CardContent className="flex flex-col items-center justify-center p-4">
              {isProcessing ? (
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              ) : (
                <>
                  <Upload className="h-8 w-8 text-muted-foreground mb-2" />
                  <p className="text-sm text-center">上传图片</p>
                  <p className="text-xs text-center text-muted-foreground mt-1">
                    用于 {getNumberForIndex(images.length)}
                  </p>
                </>
              )}
            </CardContent>
          </Card>
        )}
      </div>

      <div className="mb-6">
        <h3 className="text-lg font-medium mb-2">默认方块预览</h3>
        <p className="text-sm text-muted-foreground mb-4">这些方块将用于任何没有自定义图片的数字。</p>
        <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-2">
          {Array.from({ length: 11 }).map((_, index) => {
            const number = getNumberForIndex(index)
            const hasCustomImage = index < images.length
            return (
              <div key={index} className="aspect-square relative">
                <div
                  className={`absolute inset-0 flex items-center justify-center rounded-md overflow-hidden ${
                    hasCustomImage ? "opacity-50" : ""
                  }`}
                >
                  <img
                    src={generateNumberImage(number) || "/placeholder.svg"}
                    alt={`默认 ${number}`}
                    className="w-full h-full object-cover"
                  />
                </div>
                {hasCustomImage && (
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="bg-background/80 px-2 py-1 rounded text-xs">自定义</span>
                  </div>
                )}
              </div>
            )
          })}
        </div>
      </div>

      <input
        type="file"
        accept="image/*"
        className="hidden"
        ref={fileInputRef}
        onChange={handleFileChange}
        multiple
        disabled={isProcessing}
      />

      <div className="flex justify-center">
        <Button onClick={onStart} className="px-8" disabled={isProcessing}>
          <Play className="mr-2 h-4 w-4" />
          开始游戏
        </Button>
      </div>
    </div>
  )
}
