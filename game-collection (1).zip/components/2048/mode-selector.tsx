"use client"

import { Card, CardContent } from "@/components/ui/card"

type GameMode = "classic" | "custom"

interface ModeSelectorProps {
  onSelect: (mode: GameMode) => void
}

export function ModeSelector({ onSelect }: ModeSelectorProps) {
  const modes = [
    {
      value: "classic",
      label: "经典模式",
      description: "玩原版2048游戏，使用数字方块。",
      icon: "🎮",
    },
    {
      value: "custom",
      label: "自定义模式",
      description: "上传您自己的图片作为游戏中的方块。",
      icon: "🖼️",
    },
  ]

  return (
    <div className="w-full max-w-md">
      <h2 className="text-2xl font-semibold mb-6 text-center">选择游戏模式</h2>

      <div className="space-y-4">
        {modes.map((mode) => (
          <Card
            key={mode.value}
            className="cursor-pointer hover:shadow-md transition-all"
            onClick={() => onSelect(mode.value as GameMode)}
          >
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="text-4xl">{mode.icon}</div>
                <div>
                  <h3 className="text-xl font-medium mb-2">{mode.label}</h3>
                  <p className="text-muted-foreground">{mode.description}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
