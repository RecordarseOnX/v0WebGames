"use client"

import { useState, useEffect, useCallback, useRef } from "react"
import { Button } from "@/components/ui/button"
import { RotateCcw, ArrowUp, ArrowDown, ArrowLeft, ArrowRight } from "lucide-react"
import { useMobile } from "@/hooks/use-mobile"
import { generateNumberImage } from "@/utils/number-images"
import confetti from "canvas-confetti"

type GameMode = "classic" | "custom"

interface Game2048Props {
  mode: GameMode
  customImages: string[]
  onReset: () => void
}

interface Tile {
  id: number
  value: number
  position: [number, number]
  isNew: boolean
  isMerged: boolean
}

export function Game2048({ mode, customImages, onReset }: Game2048Props) {
  // 游戏状态
  const [grid, setGrid] = useState<number[][]>([
    [0, 0, 0, 0],
    [0, 0, 0, 0],
    [0, 0, 0, 0],
    [0, 0, 0, 0],
  ])
  const [tiles, setTiles] = useState<Tile[]>([])
  const [score, setScore] = useState(0)
  const [bestScore, setBestScore] = useState(0)
  const [gameOver, setGameOver] = useState(false)
  const [won, setWon] = useState(false)
  const [keepPlaying, setKeepPlaying] = useState(false)
  const [nextId, setNextId] = useState(0)
  const [isAnimating, setIsAnimating] = useState(false)

  const isMobile = useMobile()
  const gameContainerRef = useRef<HTMLDivElement>(null)
  const touchStartRef = useRef<{ x: number; y: number } | null>(null)

  // 初始化游戏
  useEffect(() => {
    // 尝试从本地存储加载最高分
    try {
      const savedBestScore = localStorage.getItem("2048-best-score")
      if (savedBestScore) {
        setBestScore(Number.parseInt(savedBestScore, 10))
      }
    } catch (error) {
      console.error("加载最高分时出错:", error)
    }

    // 初始化游戏
    initGame()

    // 添加键盘事件监听器
    window.addEventListener("keydown", handleKeyDown)

    return () => {
      window.removeEventListener("keydown", handleKeyDown)
    }
  }, [])

  // 当最高分变化时保存到本地存储
  useEffect(() => {
    try {
      localStorage.setItem("2048-best-score", bestScore.toString())
    } catch (error) {
      console.error("保存最高分时出错:", error)
    }
  }, [bestScore])

  // 初始化游戏
  const initGame = useCallback(() => {
    // 重置游戏状态
    const newGrid = [
      [0, 0, 0, 0],
      [0, 0, 0, 0],
      [0, 0, 0, 0],
      [0, 0, 0, 0],
    ]

    setGrid(newGrid)
    setTiles([])
    setScore(0)
    setGameOver(false)
    setWon(false)
    setKeepPlaying(false)
    setNextId(0)

    // 添加两个初始方块
    const gridWithTiles = [...newGrid]
    const newTiles: Tile[] = []

    // 添加第一个方块
    const tile1 = addRandomTile(gridWithTiles)
    if (tile1) {
      newTiles.push(tile1)
      gridWithTiles[tile1.position[0]][tile1.position[1]] = tile1.value
    }

    // 添加第二个方块
    const tile2 = addRandomTile(gridWithTiles)
    if (tile2) {
      newTiles.push(tile2)
      gridWithTiles[tile2.position[0]][tile2.position[1]] = tile2.value
    }

    setGrid(gridWithTiles)
    setTiles(newTiles)
  }, [])

  // 添加随机方块
  const addRandomTile = useCallback(
    (currentGrid: number[][]) => {
      // 找出所有空位置
      const emptyCells: [number, number][] = []
      for (let row = 0; row < 4; row++) {
        for (let col = 0; col < 4; col++) {
          if (currentGrid[row][col] === 0) {
            emptyCells.push([row, col])
          }
        }
      }

      if (emptyCells.length === 0) return null

      // 随机选择一个空位置
      const [row, col] = emptyCells[Math.floor(Math.random() * emptyCells.length)]

      // 90% 概率生成 2，10% 概率生成 4
      const value = Math.random() < 0.9 ? 2 : 4

      // 创建新方块
      const newTile: Tile = {
        id: nextId,
        value,
        position: [row, col],
        isNew: true,
        isMerged: false,
      }

      setNextId((prev) => prev + 1)
      return newTile
    },
    [nextId],
  )

  // 处理键盘事件
  const handleKeyDown = useCallback(
    (event: KeyboardEvent) => {
      if (isAnimating || gameOver) return

      let moved = false

      switch (event.key) {
        case "ArrowUp":
          moved = move("up")
          break
        case "ArrowDown":
          moved = move("down")
          break
        case "ArrowLeft":
          moved = move("left")
          break
        case "ArrowRight":
          moved = move("right")
          break
        default:
          return
      }

      if (moved) {
        event.preventDefault()
      }
    },
    [isAnimating, gameOver],
  )

  // 处理触摸事件
  useEffect(() => {
    const container = gameContainerRef.current
    if (!container) return

    const handleTouchStart = (e: TouchEvent) => {
      const touch = e.touches[0]
      touchStartRef.current = { x: touch.clientX, y: touch.clientY }
    }

    const handleTouchEnd = (e: TouchEvent) => {
      if (!touchStartRef.current || isAnimating || gameOver) return

      const touch = e.changedTouches[0]
      const deltaX = touch.clientX - touchStartRef.current.x
      const deltaY = touch.clientY - touchStartRef.current.y

      // 根据滑动方向移动方块
      if (Math.abs(deltaX) > Math.abs(deltaY)) {
        // 水平滑动
        if (Math.abs(deltaX) > 30) {
          if (deltaX > 0) {
            move("right")
          } else {
            move("left")
          }
        }
      } else {
        // 垂直滑动
        if (Math.abs(deltaY) > 30) {
          if (deltaY > 0) {
            move("down")
          } else {
            move("up")
          }
        }
      }

      touchStartRef.current = null
    }

    container.addEventListener("touchstart", handleTouchStart)
    container.addEventListener("touchend", handleTouchEnd)

    return () => {
      container.removeEventListener("touchstart", handleTouchStart)
      container.removeEventListener("touchend", handleTouchEnd)
    }
  }, [isAnimating, gameOver])

  // 移动方块
  const move = useCallback(
    (direction: "up" | "down" | "left" | "right") => {
      if (isAnimating) return false

      setIsAnimating(true)

      // 克隆当前网格和方块
      const newGrid = grid.map((row) => [...row])
      let newTiles = tiles.map((tile) => ({ ...tile, isNew: false, isMerged: false }))

      let moved = false
      let scoreIncrease = 0

      // 根据方向处理移动
      if (direction === "left") {
        // 从左到右处理每一行
        for (let row = 0; row < 4; row++) {
          const result = moveRowOrColumn(
            newGrid[row],
            newTiles,
            (col) => [row, col],
            (col, newCol) => [row, newCol],
            [0, 1, 2, 3],
          )

          newGrid[row] = result.line
          newTiles = result.tiles
          moved = moved || result.moved
          scoreIncrease += result.score
        }
      } else if (direction === "right") {
        // 从右到左处理每一行
        for (let row = 0; row < 4; row++) {
          const result = moveRowOrColumn(
            newGrid[row],
            newTiles,
            (col) => [row, col],
            (col, newCol) => [row, newCol],
            [3, 2, 1, 0],
          )

          newGrid[row] = result.line
          newTiles = result.tiles
          moved = moved || result.moved
          scoreIncrease += result.score
        }
      } else if (direction === "up") {
        // 从上到下处理每一列
        for (let col = 0; col < 4; col++) {
          const column = [newGrid[0][col], newGrid[1][col], newGrid[2][col], newGrid[3][col]]

          const result = moveRowOrColumn(
            column,
            newTiles,
            (row) => [row, col],
            (row, newRow) => [newRow, col],
            [0, 1, 2, 3],
          )

          // 更新列
          for (let row = 0; row < 4; row++) {
            newGrid[row][col] = result.line[row]
          }

          newTiles = result.tiles
          moved = moved || result.moved
          scoreIncrease += result.score
        }
      } else if (direction === "down") {
        // 从下到上处理每一列
        for (let col = 0; col < 4; col++) {
          const column = [newGrid[0][col], newGrid[1][col], newGrid[2][col], newGrid[3][col]]

          const result = moveRowOrColumn(
            column,
            newTiles,
            (row) => [row, col],
            (row, newRow) => [newRow, col],
            [3, 2, 1, 0],
          )

          // 更新列
          for (let row = 0; row < 4; row++) {
            newGrid[row][col] = result.line[row]
          }

          newTiles = result.tiles
          moved = moved || result.moved
          scoreIncrease += result.score
        }
      }

      // 如果有移动，添加新方块
      if (moved) {
        // 更新分数
        const newScore = score + scoreIncrease
        setScore(newScore)

        // 更新最高分
        if (newScore > bestScore) {
          setBestScore(newScore)
        }

        // 添加新方块
        const newTile = addRandomTile(newGrid)
        if (newTile) {
          newTiles.push(newTile)
          newGrid[newTile.position[0]][newTile.position[1]] = newTile.value
        }

        // 检查是否获胜
        if (!won && !keepPlaying && newTiles.some((tile) => tile.value === 2048)) {
          setWon(true)
          try {
            confetti({
              particleCount: 100,
              spread: 70,
              origin: { y: 0.6 },
            })
          } catch (error) {
            console.error("Confetti error:", error)
          }
        }

        // 检查游戏是否结束
        if (isGameOverState(newGrid)) {
          setGameOver(true)
        }

        setGrid(newGrid)
        setTiles(newTiles)
      }

      // 动画结束后允许下一次移动
      setTimeout(() => {
        setIsAnimating(false)
      }, 150)

      return moved
    },
    [isAnimating, grid, tiles, score, bestScore, won, keepPlaying, gameOver, addRandomTile],
  )

  // 移动行或列
  const moveRowOrColumn = (
    line: number[],
    currentTiles: Tile[],
    getPosition: (index: number) => [number, number],
    getNewPosition: (index: number, newIndex: number) => [number, number],
    indices: number[],
  ) => {
    const newLine = [...line]
    let newTiles = [...currentTiles]
    let moved = false
    let score = 0

    // 处理每个位置
    for (let i = 1; i < indices.length; i++) {
      const currentIndex = indices[i]
      const currentValue = newLine[currentIndex]

      // 如果当前位置为空，跳过
      if (currentValue === 0) continue

      // 找到当前方块
      const currentPos = getPosition(currentIndex)
      const currentTile = newTiles.find(
        (tile) => tile.position[0] === currentPos[0] && tile.position[1] === currentPos[1],
      )

      if (!currentTile) continue

      // 找到可以移动到的最远位置
      let targetIndex = i - 1
      while (targetIndex > 0 && newLine[indices[targetIndex]] === 0) {
        targetIndex--
      }

      // 如果目标位置为空，直接移动
      if (newLine[indices[targetIndex]] === 0) {
        newLine[indices[targetIndex]] = currentValue
        newLine[currentIndex] = 0

        // 更新方块位置
        const newPos = getNewPosition(indices[targetIndex], indices[targetIndex])
        currentTile.position = newPos

        moved = true
      }
      // 如果目标位置的值与当前值相同，合并
      else if (newLine[indices[targetIndex]] === currentValue) {
        // 找到目标方块
        const targetPos = getNewPosition(indices[targetIndex], indices[targetIndex])
        const targetTile = newTiles.find(
          (tile) => tile.position[0] === targetPos[0] && tile.position[1] === targetPos[1],
        )

        if (targetTile && !targetTile.isMerged) {
          // 合并方块
          newLine[indices[targetIndex]] *= 2
          newLine[currentIndex] = 0

          // 标记目标方块为已合并
          targetTile.value *= 2
          targetTile.isMerged = true

          // 从方块数组中移除当前方块
          newTiles = newTiles.filter((tile) => tile.id !== currentTile.id)

          // 增加分数
          score += targetTile.value

          moved = true
        }
        // 如果目标方块已经合并过，移动到它旁边
        else if (targetIndex + 1 !== i) {
          newLine[indices[targetIndex + 1]] = currentValue
          newLine[currentIndex] = 0

          // 更新方块位置
          const newPos = getNewPosition(indices[targetIndex + 1], indices[targetIndex + 1])
          currentTile.position = newPos

          moved = true
        }
      }
      // 如果目标位置的值与当前值不同，移动到它旁边
      else if (targetIndex + 1 !== i) {
        newLine[indices[targetIndex + 1]] = currentValue
        newLine[currentIndex] = 0

        // 更新方块位置
        const newPos = getNewPosition(indices[targetIndex + 1], indices[targetIndex + 1])
        currentTile.position = newPos

        moved = true
      }
    }

    return { line: newLine, tiles: newTiles, moved, score }
  }

  // 检查游戏是否结束
  const isGameOverState = (currentGrid: number[][]) => {
    // 检查是否有空格
    for (let row = 0; row < 4; row++) {
      for (let col = 0; col < 4; col++) {
        if (currentGrid[row][col] === 0) {
          return false
        }
      }
    }

    // 检查是否有可以合并的相邻方块
    for (let row = 0; row < 4; row++) {
      for (let col = 0; col < 4; col++) {
        const value = currentGrid[row][col]

        // 检查右侧
        if (col < 3 && currentGrid[row][col + 1] === value) {
          return false
        }

        // 检查下方
        if (row < 3 && currentGrid[row + 1][col] === value) {
          return false
        }
      }
    }

    return true
  }

  // 处理滑动
  const handleSwipe = (direction: "up" | "down" | "left" | "right") => {
    move(direction)
  }

  // 继续游戏
  const handleContinue = () => {
    setKeepPlaying(true)
  }

  // 重新开始游戏
  const handleRestart = () => {
    initGame()
  }

  // 获取方块图像
  const getTileImage = (value: number): string => {
    if (mode === "classic") {
      return generateNumberImage(value)
    }

    // 对于自定义模式，使用上传的图像或默认图像
    const index = Math.log2(value) - 1 // 2 -> 0, 4 -> 1, 8 -> 2, 等

    if (index < customImages.length) {
      return customImages[index]
    }

    // 如果有自定义图像，对于更高的值使用最后一个
    if (customImages.length > 0 && index >= customImages.length) {
      return customImages[customImages.length - 1]
    }

    // 默认使用数字图像
    return generateNumberImage(value)
  }

  // 获取方块颜色
  const getTileColor = (value: number): string => {
    const colors: { [key: number]: string } = {
      2: "bg-[#eee4da] text-[#776e65]",
      4: "bg-[#ede0c8] text-[#776e65]",
      8: "bg-[#f2b179] text-white",
      16: "bg-[#f59563] text-white",
      32: "bg-[#f67c5f] text-white",
      64: "bg-[#f65e3b] text-white",
      128: "bg-[#edcf72] text-white",
      256: "bg-[#edcc61] text-white",
      512: "bg-[#edc850] text-white",
      1024: "bg-[#edc53f] text-white",
      2048: "bg-[#edc22e] text-white",
    }

    return colors[value] || "bg-[#3c3a32] text-white"
  }

  // 获取字体大小
  const getFontSize = (value: number): string => {
    if (value < 100) return "text-3xl sm:text-5xl"
    if (value < 1000) return "text-2xl sm:text-4xl"
    return "text-xl sm:text-3xl"
  }

  return (
    <div className="w-full max-w-lg mx-auto">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-2xl font-bold">2048</h2>
          <p className="text-sm text-muted-foreground">{mode === "classic" ? "经典模式" : "自定义模式"}</p>
        </div>
        <div className="flex gap-4">
          <div className="bg-muted rounded-md p-2 text-center min-w-[80px]">
            <div className="text-xs text-muted-foreground">分数</div>
            <div className="font-bold">{score}</div>
          </div>
          <div className="bg-muted rounded-md p-2 text-center min-w-[80px]">
            <div className="text-xs text-muted-foreground">最高分</div>
            <div className="font-bold">{bestScore}</div>
          </div>
        </div>
      </div>

      <div className="flex justify-between items-center mb-4">
        <Button variant="outline" size="sm" onClick={handleRestart}>
          <RotateCcw className="mr-2 h-4 w-4" />
          新游戏
        </Button>
        <Button variant="outline" size="sm" onClick={onReset}>
          返回菜单
        </Button>
      </div>

      {won && !keepPlaying && (
        <div className="bg-green-100 dark:bg-green-900/30 p-4 rounded-lg mb-6 text-center">
          <h3 className="text-xl font-bold text-green-700 dark:text-green-300 mb-2">你赢了！</h3>
          <p className="mb-4">你已经达到了2048！</p>
          <div className="flex justify-center gap-4">
            <Button variant="outline" onClick={handleRestart}>
              开始新游戏
            </Button>
            <Button onClick={handleContinue}>继续游戏</Button>
          </div>
        </div>
      )}

      {gameOver && (
        <div className="bg-red-100 dark:bg-red-900/30 p-4 rounded-lg mb-6 text-center">
          <h3 className="text-xl font-bold text-red-700 dark:text-red-300 mb-2">游戏结束！</h3>
          <p className="mb-4">没有更多可用的移动。</p>
          <Button onClick={handleRestart}>再试一次</Button>
        </div>
      )}

      {/* 游戏面板 */}
      <div ref={gameContainerRef} className="relative bg-[#bbada0] rounded-lg p-2 sm:p-3 mb-6 aspect-square touch-none">
        {/* 网格背景 */}
        <div className="absolute inset-2 sm:inset-3 grid grid-cols-4 grid-rows-4 gap-2">
          {Array.from({ length: 16 }).map((_, index) => (
            <div key={`grid-${index}`} className="bg-[#cdc1b4] rounded-md"></div>
          ))}
        </div>

        {/* 方块 */}
        <div className="relative w-full h-full">
          {tiles.map((tile) => {
            const { row, col } = { row: tile.position[0], col: tile.position[1] }
            const translateX = `calc(${col * 100}% + ${col * 8}px)`
            const translateY = `calc(${row * 100}% + ${row * 8}px)`

            return (
              <div
                key={`tile-${tile.id}`}
                className={`absolute w-[calc(25%-6px)] h-[calc(25%-6px)] rounded-md flex items-center justify-center 
                  transition-all duration-150 ${tile.isNew ? "scale-0" : "scale-100"} ${
                    tile.isMerged ? "scale-110" : ""
                  }`}
                style={{
                  transform: `translate(${translateX}, ${translateY})`,
                }}
              >
                {mode === "custom" ? (
                  <div className="relative w-full h-full rounded-md overflow-hidden">
                    <img
                      src={getTileImage(tile.value) || "/placeholder.svg"}
                      alt={`方块 ${tile.value}`}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <span className={`font-bold ${getFontSize(tile.value)} text-white drop-shadow-lg`}>
                        {tile.value}
                      </span>
                    </div>
                  </div>
                ) : (
                  <div
                    className={`w-full h-full rounded-md flex items-center justify-center font-bold ${getTileColor(
                      tile.value,
                    )} ${getFontSize(tile.value)}`}
                  >
                    {tile.value}
                  </div>
                )}
              </div>
            )
          })}
        </div>
      </div>

      {/* 移动设备的触摸控制 */}
      {isMobile && (
        <div className="grid grid-cols-3 gap-2 max-w-[200px] mx-auto">
          <div className="col-start-2">
            <Button variant="outline" size="icon" className="w-full aspect-square" onClick={() => handleSwipe("up")}>
              <ArrowUp className="h-6 w-6" />
            </Button>
          </div>
          <div className="col-start-1 row-start-2">
            <Button variant="outline" size="icon" className="w-full aspect-square" onClick={() => handleSwipe("left")}>
              <ArrowLeft className="h-6 w-6" />
            </Button>
          </div>
          <div className="col-start-3 row-start-2">
            <Button variant="outline" size="icon" className="w-full aspect-square" onClick={() => handleSwipe("right")}>
              <ArrowRight className="h-6 w-6" />
            </Button>
          </div>
          <div className="col-start-2 row-start-3">
            <Button variant="outline" size="icon" className="w-full aspect-square" onClick={() => handleSwipe("down")}>
              <ArrowDown className="h-6 w-6" />
            </Button>
          </div>
        </div>
      )}

      <div className="text-center text-sm text-muted-foreground mt-6">
        <p>使用方向键或滑动来移动方块。当两个相同数字的方块相遇时，它们会合并成一个！</p>
      </div>
    </div>
  )
}
