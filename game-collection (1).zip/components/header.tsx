"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Home, Menu, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useState } from "react"
import { ModeToggle } from "./mode-toggle"

export default function Header() {
  const pathname = usePathname()
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen)
  }

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-2">
          <Link href="/" className="flex items-center gap-2">
            <Home className="h-6 w-6" />
            <span className="font-bold text-xl hidden sm:inline-block">网页游戏</span>
          </Link>
        </div>

        <nav className="hidden md:flex items-center gap-6">
          <Link
            href="/"
            className={`text-sm font-medium transition-colors hover:text-primary ${
              pathname === "/" ? "text-foreground" : "text-muted-foreground"
            }`}
          >
            首页
          </Link>
          <Link
            href="/games/klotski"
            className={`text-sm font-medium transition-colors hover:text-primary ${
              pathname.includes("/games/klotski") ? "text-foreground" : "text-muted-foreground"
            }`}
          >
            华容道拼图
          </Link>
          <Link
            href="/games/memory"
            className={`text-sm font-medium transition-colors hover:text-primary ${
              pathname.includes("/games/memory") ? "text-foreground" : "text-muted-foreground"
            }`}
          >
            记忆配对
          </Link>
          <Link
            href="/games/2048"
            className={`text-sm font-medium transition-colors hover:text-primary ${
              pathname.includes("/games/2048") ? "text-foreground" : "text-muted-foreground"
            }`}
          >
            2048
          </Link>
          <ModeToggle />
        </nav>

        <div className="md:hidden flex items-center gap-4">
          <ModeToggle />
          <Button variant="ghost" size="icon" onClick={toggleMenu}>
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </Button>
        </div>
      </div>

      {isMenuOpen && (
        <div className="md:hidden container py-4 border-t">
          <nav className="flex flex-col space-y-4">
            <Link
              href="/"
              className={`text-sm font-medium transition-colors hover:text-primary ${
                pathname === "/" ? "text-foreground" : "text-muted-foreground"
              }`}
              onClick={() => setIsMenuOpen(false)}
            >
              首页
            </Link>
            <Link
              href="/games/klotski"
              className={`text-sm font-medium transition-colors hover:text-primary ${
                pathname.includes("/games/klotski") ? "text-foreground" : "text-muted-foreground"
              }`}
              onClick={() => setIsMenuOpen(false)}
            >
              华容道拼图
            </Link>
            <Link
              href="/games/memory"
              className={`text-sm font-medium transition-colors hover:text-primary ${
                pathname.includes("/games/memory") ? "text-foreground" : "text-muted-foreground"
              }`}
              onClick={() => setIsMenuOpen(false)}
            >
              记忆配对
            </Link>
            <Link
              href="/games/2048"
              className={`text-sm font-medium transition-colors hover:text-primary ${
                pathname.includes("/games/2048") ? "text-foreground" : "text-muted-foreground"
              }`}
              onClick={() => setIsMenuOpen(false)}
            >
              2048
            </Link>
          </nav>
        </div>
      )}
    </header>
  )
}
