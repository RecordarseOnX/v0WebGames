"use client"

import { useState, useEffect, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Shuffle, RotateCcw } from "lucide-react"
import { useMobile } from "@/hooks/use-mobile"
import { processImage } from "@/utils/image-processing"
import confetti from "canvas-confetti"

interface KlotskiGameProps {
  imageSrc: string
  difficulty: "3x3" | "4x4" | "5x5"
}

interface Tile {
  id: number
  currentPos: number
  correctPos: number
  imgPart: string
}

export function KlotskiGame({ imageSrc, difficulty }: KlotskiGameProps) {
  const [tiles, setTiles] = useState<Tile[]>([])
  const [emptyIndex, setEmptyIndex] = useState<number>(0)
  const [isLoading, setIsLoading] = useState(true)
  const [isShuffling, setIsShuffling] = useState(false)
  const [moves, setMoves] = useState(0)
  const [isComplete, setIsComplete] = useState(false)
  const [processedImage, setProcessedImage] = useState<string | null>(null)
  const [imageParts, setImageParts] = useState<string[]>([])
  const [error, setError] = useState<string | null>(null)
  const [showSuccessMessage, setShowSuccessMessage] = useState(false)
  const isMobile = useMobile()

  const gridSize = Number.parseInt(difficulty.split("x")[0])

  useEffect(() => {
    const loadAndProcessImage = async () => {
      setIsLoading(true)
      setError(null)

      try {
        // 处理图像并获取处理后的版本
        const processed = await processImage(imageSrc)
        setProcessedImage(processed)

        // 创建图像部分
        const parts = await createImageParts(processed, gridSize)

        if (parts.length === 0) {
          throw new Error("无法创建图像部分")
        }

        setImageParts(parts)

        // 初始化游戏
        initializeGame(parts)
      } catch (error) {
        console.error("处理图像时出错:", error)
        setError("处理图像失败。请尝试使用不同的图像。")
      } finally {
        setIsLoading(false)
      }
    }

    loadAndProcessImage()
  }, [imageSrc, difficulty, gridSize])

  const createImageParts = async (imageSrc: string, gridSize: number): Promise<string[]> => {
    return new Promise((resolve, reject) => {
      const img = new Image()

      // 设置超时以防止无限加载
      const timeoutId = setTimeout(() => {
        reject(new Error("图像加载超时"))
      }, 10000) // 10秒超时

      img.onload = () => {
        clearTimeout(timeoutId)
        const parts: string[] = []
        const canvas = document.createElement("canvas")
        const ctx = canvas.getContext("2d")

        if (!ctx) {
          resolve([])
          return
        }

        const tileWidth = img.width / gridSize
        const tileHeight = img.height / gridSize

        canvas.width = tileWidth
        canvas.height = tileHeight

        // 修复循环条件：将 y < gridSize 改为 x < gridSize
        for (let y = 0; y < gridSize; y++) {
          for (let x = 0; x < gridSize; x++) {
            ctx.clearRect(0, 0, tileWidth, tileHeight)

            // 绘制图像部分
            ctx.drawImage(img, x * tileWidth, y * tileHeight, tileWidth, tileHeight, 0, 0, tileWidth, tileHeight)

            // 转换为数据URL
            const dataUrl = canvas.toDataURL("image/png")
            parts.push(dataUrl)
          }
        }

        resolve(parts)
      }

      img.onerror = () => {
        clearTimeout(timeoutId)
        reject(new Error("加载图像失败"))
      }

      img.crossOrigin = "anonymous"
      img.src = imageSrc
    })
  }

  const initializeGame = useCallback(
    (parts: string[]) => {
      const totalTiles = gridSize * gridSize
      const lastTileIndex = totalTiles - 1

      // 创建带有正确位置的方块
      const newTiles = Array.from({ length: totalTiles }, (_, i) => ({
        id: i,
        currentPos: i,
        correctPos: i,
        imgPart: i < parts.length ? parts[i] : "",
      }))

      // 移除最后一个方块（将是空的）
      newTiles[lastTileIndex].imgPart = ""

      // 打乱方块
      shuffleTiles(newTiles, lastTileIndex)

      // 重置完成状态
      setIsComplete(false)
      setShowSuccessMessage(false)
    },
    [gridSize],
  )

  const shuffleTiles = useCallback(
    (tilesToShuffle: Tile[], emptyPos: number) => {
      setIsShuffling(true)

      try {
        // 复制方块
        const shuffled = [...tilesToShuffle]
        const totalTiles = gridSize * gridSize

        // 执行随机移动来打乱
        let currentEmptyPos = emptyPos
        for (let i = 0; i < totalTiles * 20; i++) {
          const possibleMoves = getValidMoves(currentEmptyPos, gridSize)
          if (possibleMoves.length > 0) {
            const randomMove = possibleMoves[Math.floor(Math.random() * possibleMoves.length)]

            // 将空方块与随机相邻方块交换
            const tileToMove = shuffled.findIndex((t) => t.currentPos === randomMove)
            if (tileToMove !== -1) {
              shuffled[tileToMove].currentPos = currentEmptyPos
              currentEmptyPos = randomMove
            }
          }
        }

        // 设置空位置
        setEmptyIndex(currentEmptyPos)
        setTiles(shuffled)
        setMoves(0)
        setIsComplete(false)
        setShowSuccessMessage(false)
      } catch (error) {
        console.error("打乱过程中出错:", error)
        setError("打乱时发生错误。请重试。")
      } finally {
        setIsShuffling(false)
      }
    },
    [gridSize],
  )

  // 提取 getValidMoves 作为纯函数以避免重新创建它
  const getValidMoves = (emptyPos: number, size: number) => {
    const validMoves: number[] = []
    const row = Math.floor(emptyPos / size)
    const col = emptyPos % size

    // 检查上方
    if (row > 0) {
      validMoves.push(emptyPos - size)
    }

    // 检查下方
    if (row < size - 1) {
      validMoves.push(emptyPos + size)
    }

    // 检查左侧
    if (col > 0) {
      validMoves.push(emptyPos - 1)
    }

    // 检查右侧
    if (col < size - 1) {
      validMoves.push(emptyPos + 1)
    }

    return validMoves
  }

  const handleTileClick = useCallback(
    (tilePos: number) => {
      if (isComplete || isShuffling) return

      // 检查点击的方块是否与空位置相邻
      const validMoves = getValidMoves(emptyIndex, gridSize)
      if (!validMoves.includes(tilePos)) return

      // 找到点击位置的方块
      const tileIndex = tiles.findIndex((t) => t.currentPos === tilePos)
      if (tileIndex === -1) return

      // 移动方块
      const newTiles = [...tiles]
      newTiles[tileIndex].currentPos = emptyIndex
      setEmptyIndex(tilePos)
      setTiles(newTiles)
      setMoves(moves + 1)

      // 检查拼图是否解决
      checkCompletion(newTiles)
    },
    [emptyIndex, gridSize, isComplete, isShuffling, moves, tiles],
  )

  const checkCompletion = useCallback(
    (currentTiles: Tile[]) => {
      const isCompleted = currentTiles.every(
        (tile) =>
          tile.currentPos === tile.correctPos ||
          (tile.id === gridSize * gridSize - 1 && tile.currentPos === emptyIndex),
      )

      if (isCompleted && !isComplete) {
        setIsComplete(true)

        // 显示成功消息，稍微延迟以获得更好的用户体验
        setTimeout(() => {
          setShowSuccessMessage(true)

          // 触发彩带效果
          confetti({
            particleCount: 100,
            spread: 70,
            origin: { y: 0.6 },
          })
        }, 300)
      }
    },
    [emptyIndex, gridSize, isComplete],
  )

  const resetGame = useCallback(() => {
    if (imageParts.length > 0 && !isShuffling) {
      const totalTiles = gridSize * gridSize
      const lastTileIndex = totalTiles - 1

      // 创建带有正确位置的方块
      const newTiles = Array.from({ length: totalTiles }, (_, i) => ({
        id: i,
        currentPos: i,
        correctPos: i,
        imgPart: i < imageParts.length ? imageParts[i] : "",
      }))

      // 移除最后一个方块（将是空的）
      newTiles[lastTileIndex].imgPart = ""

      // 打乱方块
      shuffleTiles(newTiles, lastTileIndex)
    }
  }, [gridSize, imageParts, isShuffling, shuffleTiles])

  const handleShuffle = useCallback(() => {
    if (imageParts.length > 0 && !isShuffling) {
      shuffleTiles(tiles, emptyIndex)
    }
  }, [emptyIndex, imageParts, isShuffling, shuffleTiles, tiles])

  if (isLoading) {
    return (
      <div className="w-full flex justify-center items-center py-12">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p>加载拼图中...</p>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="w-full flex justify-center items-center py-12">
        <div className="text-center">
          <p className="text-red-500 mb-4">{error}</p>
          <Button onClick={() => window.location.reload()}>重试</Button>
        </div>
      </div>
    )
  }

  return (
    <div className="w-full">
      <div className="flex justify-between items-center mb-6">
        <div>
          <p className="text-lg font-medium">步数: {moves}</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={resetGame} disabled={isShuffling}>
            <RotateCcw className="mr-2 h-4 w-4" />
            重置
          </Button>
          <Button variant="outline" size="sm" onClick={handleShuffle} disabled={isShuffling}>
            <Shuffle className="mr-2 h-4 w-4" />
            {isShuffling ? "打乱中..." : "打乱"}
          </Button>
        </div>
      </div>

      {showSuccessMessage && (
        <div className="bg-green-100 dark:bg-green-900/30 p-4 rounded-lg mb-6 text-center animate-fadeIn">
          <h3 className="text-xl font-bold text-green-700 dark:text-green-300 mb-2">恭喜！</h3>
          <p>您已成功完成拼图，用了 {moves} 步！</p>
        </div>
      )}

      <div className={`grid ${isMobile ? "grid-cols-1 gap-8" : "grid-cols-2 gap-12"}`}>
        {/* 游戏面板 */}
        <div className="aspect-square w-full">
          <div
            className={`w-full h-full grid ${isComplete ? "gap-0" : "gap-1"} p-1 bg-muted rounded-lg ${
              isShuffling ? "opacity-70 pointer-events-none" : ""
            } transition-all duration-300`}
            style={{
              gridTemplateColumns: `repeat(${gridSize}, 1fr)`,
              gridTemplateRows: `repeat(${gridSize}, 1fr)`,
            }}
          >
            {Array.from({ length: gridSize * gridSize }).map((_, index) => {
              const tile = tiles.find((t) => t.currentPos === index)
              const isEmpty = index === emptyIndex

              return (
                <div
                  key={index}
                  className={`relative ${!isEmpty && !isShuffling ? "cursor-pointer" : ""} 
                    ${isComplete ? "rounded-none" : "rounded-md"} overflow-hidden transition-all duration-300
                    ${!isEmpty ? "hover:brightness-90" : isComplete ? "bg-transparent" : "bg-muted-foreground/10"}`}
                  onClick={() => !isEmpty && handleTileClick(index)}
                >
                  {!isEmpty && tile && (
                    <img
                      src={tile.imgPart || "/placeholder.svg"}
                      alt={`方块 ${tile.id}`}
                      className="w-full h-full object-cover"
                    />
                  )}
                </div>
              )
            })}
          </div>
        </div>

        {/* 预览区域 */}
        <div className="aspect-square w-full bg-muted rounded-lg p-4 flex items-center justify-center">
          {processedImage ? (
            <img
              src={processedImage || "/placeholder.svg"}
              alt="完整拼图预览"
              className="max-w-full max-h-full object-contain"
            />
          ) : (
            <div className="text-center text-muted-foreground">预览图像不可用</div>
          )}
        </div>
      </div>
    </div>
  )
}
