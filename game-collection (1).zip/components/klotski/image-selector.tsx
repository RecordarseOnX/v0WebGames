"use client"

import type React from "react"

import { useState, useRef } from "react"
import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Upload } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

interface ImageSelectorProps {
  onSelect: (imageSrc: string) => void
}

const EXAMPLE_IMAGES = [
  {
    name: "蒙娜丽莎",
    src: "/placeholder.svg?height=400&width=300",
    alt: "达芬奇的蒙娜丽莎",
  },
  {
    name: "星空",
    src: "/placeholder.svg?height=400&width=500",
    alt: "梵高的星空",
  },
  {
    name: "呐喊",
    src: "/placeholder.svg?height=400&width=320",
    alt: "蒙克的呐喊",
  },
  {
    name: "戴珍珠耳环的少女",
    src: "/placeholder.svg?height=400&width=350",
    alt: "维米尔的戴珍珠耳环的少女",
  },
]

export function ImageSelector({ onSelect }: ImageSelectorProps) {
  const [uploadedImage, setUploadedImage] = useState<string | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (event) => {
        if (event.target?.result) {
          setUploadedImage(event.target.result as string)
        }
      }
      reader.readAsDataURL(file)
    }
  }

  const handleUploadClick = () => {
    fileInputRef.current?.click()
  }

  return (
    <div className="w-full max-w-3xl">
      <h2 className="text-2xl font-semibold mb-6 text-center">为您的拼图选择一张图片</h2>

      <Tabs defaultValue="upload" className="w-full">
        <TabsList className="grid w-full grid-cols-2 mb-6">
          <TabsTrigger value="upload">上传您自己的图片</TabsTrigger>
          <TabsTrigger value="examples">示例图片</TabsTrigger>
        </TabsList>

        <TabsContent value="upload" className="space-y-4">
          <div className="flex flex-col items-center">
            <input type="file" accept="image/*" className="hidden" ref={fileInputRef} onChange={handleFileChange} />

            {uploadedImage ? (
              <div className="w-full max-w-md">
                <div className="aspect-square w-full relative mb-4 border rounded-md overflow-hidden">
                  <img
                    src={uploadedImage || "/placeholder.svg"}
                    alt="已上传图片"
                    className="w-full h-full object-contain"
                  />
                </div>
                <div className="flex gap-4 justify-center">
                  <Button variant="outline" onClick={handleUploadClick}>
                    选择不同图片
                  </Button>
                  <Button onClick={() => onSelect(uploadedImage)}>使用此图片</Button>
                </div>
              </div>
            ) : (
              <Card
                className="w-full max-w-md cursor-pointer hover:bg-muted/50 transition-colors"
                onClick={handleUploadClick}
              >
                <CardContent className="flex flex-col items-center justify-center h-64 p-6">
                  <Upload className="h-12 w-12 text-muted-foreground mb-4" />
                  <p className="text-lg font-medium mb-2">上传图片</p>
                  <p className="text-sm text-muted-foreground text-center mb-4">点击从您的设备中选择图片</p>
                  <Button>选择图片</Button>
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>

        <TabsContent value="examples">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {EXAMPLE_IMAGES.map((image, index) => (
              <Card
                key={index}
                className="overflow-hidden cursor-pointer hover:shadow-md transition-all"
                onClick={() => onSelect(image.src)}
              >
                <div className="aspect-square relative">
                  <Image src={image.src || "/placeholder.svg"} alt={image.alt} fill className="object-cover" />
                </div>
                <CardContent className="p-4">
                  <p className="font-medium text-center">{image.name}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
