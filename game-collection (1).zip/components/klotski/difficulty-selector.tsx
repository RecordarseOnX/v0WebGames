"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { ArrowLeft } from "lucide-react"

type Difficulty = "3x3" | "4x4" | "5x5"

interface DifficultySelectorProps {
  onSelect: (difficulty: Difficulty) => void
  onBack: () => void
}

export function DifficultySelector({ onSelect, onBack }: DifficultySelectorProps) {
  const difficulties: { value: Difficulty; label: string; description: string }[] = [
    {
      value: "3x3",
      label: "简单 (3×3)",
      description: "一个简单的9块拼图，适合初学者。",
    },
    {
      value: "4x4",
      label: "中等 (4×4)",
      description: "一个中等难度的16块拼图。",
    },
    {
      value: "5x5",
      label: "困难 (5×5)",
      description: "一个困难的25块拼图，适合专家。",
    },
  ]

  return (
    <div className="w-full max-w-md">
      <div className="mb-6">
        <Button variant="outline" onClick={onBack}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          返回图片选择
        </Button>
      </div>

      <h2 className="text-2xl font-semibold mb-6 text-center">选择难度级别</h2>

      <div className="space-y-4">
        {difficulties.map((difficulty) => (
          <Card
            key={difficulty.value}
            className="cursor-pointer hover:shadow-md transition-all"
            onClick={() => onSelect(difficulty.value)}
          >
            <CardContent className="p-6">
              <h3 className="text-xl font-medium mb-2">{difficulty.label}</h3>
              <p className="text-muted-foreground">{difficulty.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
