"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Upload, X, ArrowLeft, Play } from "lucide-react"
import { alphabetImages, generateLetterImage } from "@/utils/alphabet-images"

type Difficulty = "4x2" | "6x2" | "8x2"

interface ImageUploaderProps {
  maxImages: number
  onImagesSelected: (images: string[]) => void
  onStart: () => void
  onBack: () => void
  difficulty: Difficulty
}

export function ImageUploader({ maxImages, onImagesSelected, onStart, onBack, difficulty }: ImageUploaderProps) {
  const [uploadedImages, setUploadedImages] = useState<string[]>([])
  const [isProcessing, setIsProcessing] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files || uploadedImages.length >= maxImages) return

    setIsProcessing(true)
    const newImages: string[] = [...uploadedImages]
    let filesProcessed = 0
    const totalFiles = Math.min(files.length, maxImages - uploadedImages.length)

    Array.from(files).forEach((file, index) => {
      if (newImages.length < maxImages) {
        const reader = new FileReader()
        reader.onload = (event) => {
          if (event.target?.result) {
            newImages.push(event.target.result as string)
            filesProcessed++

            if (filesProcessed === totalFiles) {
              setUploadedImages([...newImages])
              setIsProcessing(false)
            }
          }
        }
        reader.onerror = () => {
          filesProcessed++
          if (filesProcessed === totalFiles) {
            setUploadedImages([...newImages])
            setIsProcessing(false)
          }
        }
        reader.readAsDataURL(file)
      }
    })
  }

  const handleRemoveImage = (index: number) => {
    const newImages = [...uploadedImages]
    newImages.splice(index, 1)
    setUploadedImages(newImages)
  }

  const handleUploadClick = () => {
    fileInputRef.current?.click()
  }

  const handleStart = () => {
    // 为任何缺少的槽位生成示例图像
    const finalImages = [...uploadedImages]

    // 如果我们的图像少于所需的数量，添加示例图像
    if (finalImages.length < maxImages) {
      // 使用字母图像填充剩余的槽位
      for (let i = 0; i < maxImages - finalImages.length; i++) {
        const letterInfo = alphabetImages[i % alphabetImages.length]
        const letterImage = generateLetterImage(letterInfo.letter, letterInfo.color)
        finalImages.push(letterImage)
      }
    }

    onImagesSelected(finalImages)
    onStart()
  }

  return (
    <div className="w-full max-w-3xl">
      <div className="mb-6">
        <Button variant="outline" onClick={onBack}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          返回难度选择
        </Button>
      </div>

      <h2 className="text-2xl font-semibold mb-4 text-center">上传图片（可选）</h2>
      <p className="text-center text-muted-foreground mb-6">
        为您的记忆游戏上传最多 {maxImages} 张图片，或使用我们的字母卡片。
      </p>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
        {/* 显示已上传的图片 */}
        {uploadedImages.map((image, index) => (
          <div key={index} className="relative aspect-square">
            <div className="w-full h-full border rounded-md overflow-hidden bg-white">
              <img
                src={image || "/placeholder.svg"}
                alt={`已上传 ${index + 1}`}
                className="w-full h-full object-contain"
              />
            </div>
            <button
              className="absolute top-2 right-2 bg-background/80 rounded-full p-1 hover:bg-background"
              onClick={() => handleRemoveImage(index)}
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        ))}

        {/* 为剩余槽位上传按钮 */}
        {uploadedImages.length < maxImages && (
          <Card
            className="aspect-square cursor-pointer hover:bg-muted/50 transition-colors flex items-center justify-center"
            onClick={handleUploadClick}
          >
            <CardContent className="flex flex-col items-center justify-center p-4">
              {isProcessing ? (
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              ) : (
                <>
                  <Upload className="h-8 w-8 text-muted-foreground mb-2" />
                  <p className="text-sm text-center">上传图片</p>
                </>
              )}
            </CardContent>
          </Card>
        )}
      </div>

      <input
        type="file"
        accept="image/*"
        className="hidden"
        ref={fileInputRef}
        onChange={handleFileChange}
        multiple
        disabled={isProcessing}
      />

      <div className="flex justify-center">
        <Button onClick={handleStart} className="px-8" disabled={isProcessing}>
          <Play className="mr-2 h-4 w-4" />
          开始游戏
        </Button>
      </div>
    </div>
  )
}
