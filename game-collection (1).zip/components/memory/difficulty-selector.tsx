"use client"
import { Card, CardContent } from "@/components/ui/card"

type Difficulty = "4x2" | "6x2" | "8x2"

interface DifficultySelectorProps {
  onSelect: (difficulty: Difficulty) => void
}

export function DifficultySelector({ onSelect }: DifficultySelectorProps) {
  const difficulties: { value: Difficulty; label: string; description: string }[] = [
    {
      value: "4x2",
      label: "简单 (4×2)",
      description: "8张卡片需要匹配 (4对)",
    },
    {
      value: "6x2",
      label: "中等 (6×2)",
      description: "12张卡片需要匹配 (6对)",
    },
    {
      value: "8x2",
      label: "困难 (8×2)",
      description: "16张卡片需要匹配 (8对)",
    },
  ]

  return (
    <div className="w-full max-w-md">
      <h2 className="text-2xl font-semibold mb-6 text-center">选择难度级别</h2>

      <div className="space-y-4">
        {difficulties.map((difficulty) => (
          <Card
            key={difficulty.value}
            className="cursor-pointer hover:shadow-md transition-all"
            onClick={() => onSelect(difficulty.value)}
          >
            <CardContent className="p-6">
              <h3 className="text-xl font-medium mb-2">{difficulty.label}</h3>
              <p className="text-muted-foreground">{difficulty.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
