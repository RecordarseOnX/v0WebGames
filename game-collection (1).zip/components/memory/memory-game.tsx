"use client"

import { useState, useEffect, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { RotateCcw, Timer, Trophy } from "lucide-react"
import { useMobile } from "@/hooks/use-mobile"
import { alphabetImages, generateLetterImage } from "@/utils/alphabet-images"
import confetti from "canvas-confetti"

type Difficulty = "4x2" | "6x2" | "8x2"

interface MemoryGameProps {
  difficulty: Difficulty
  uploadedImages: string[]
  onReset: () => void
}

interface Card {
  id: number
  imageUrl: string
  isFlipped: boolean
  isMatched: boolean
}

export function MemoryGame({ difficulty, uploadedImages, onReset }: MemoryGameProps) {
  const [cards, setCards] = useState<Card[]>([])
  const [flippedCards, setFlippedCards] = useState<number[]>([])
  const [matchedPairs, setMatchedPairs] = useState<number>(0)
  const [moves, setMoves] = useState<number>(0)
  const [isGameComplete, setIsGameComplete] = useState<boolean>(false)
  const [timer, setTimer] = useState<number>(0)
  const [isGameStarted, setIsGameStarted] = useState<boolean>(false)
  const [isLoading, setIsLoading] = useState<boolean>(true)
  const isMobile = useMobile()

  // 解析难度以获取对数
  const numPairs = Number.parseInt(difficulty.split("x")[0])
  const totalCards = numPairs * 2

  // 使用字母图像作为备用
  const generateDefaultImages = useCallback(() => {
    const images: string[] = []
    for (let i = 0; i < numPairs; i++) {
      const letterInfo = alphabetImages[i % alphabetImages.length]
      const letterImage = generateLetterImage(letterInfo.letter, letterInfo.color)
      images.push(letterImage)
    }
    return images
  }, [numPairs])

  // 初始化游戏
  useEffect(() => {
    const initGame = async () => {
      setIsLoading(true)

      try {
        // 处理上传的图像
        let gameImages: string[] = []

        // 如果有上传的图像，使用它们
        if (uploadedImages.length > 0) {
          gameImages = [...uploadedImages]
          // 如果上传的图像不够，用字母图像补充
          if (gameImages.length < numPairs) {
            const defaultImages = generateDefaultImages()
            gameImages = [...gameImages, ...defaultImages.slice(0, numPairs - gameImages.length)]
          }
        } else {
          // 没有上传图像，使用默认字母图像
          gameImages = generateDefaultImages()
        }

        // 限制为所需的对数
        gameImages = gameImages.slice(0, numPairs)

        // 创建卡片
        let cardPairs: Card[] = []
        for (let i = 0; i < numPairs; i++) {
          // 创建一对相同图像的卡片
          cardPairs.push({
            id: i * 2,
            imageUrl: gameImages[i],
            isFlipped: false,
            isMatched: false,
          })

          cardPairs.push({
            id: i * 2 + 1,
            imageUrl: gameImages[i],
            isFlipped: false,
            isMatched: false,
          })
        }

        // 洗牌
        cardPairs = shuffleCards(cardPairs)
        setCards(cardPairs)
      } catch (error) {
        console.error("初始化游戏时出错:", error)
        // 出错时使用默认图像
        const defaultImages = generateDefaultImages()
        let cardPairs: Card[] = []

        for (let i = 0; i < numPairs; i++) {
          cardPairs.push({
            id: i * 2,
            imageUrl: defaultImages[i],
            isFlipped: false,
            isMatched: false,
          })

          cardPairs.push({
            id: i * 2 + 1,
            imageUrl: defaultImages[i],
            isFlipped: false,
            isMatched: false,
          })
        }

        cardPairs = shuffleCards(cardPairs)
        setCards(cardPairs)
      } finally {
        setIsLoading(false)
      }
    }

    initGame()
  }, [difficulty, numPairs, uploadedImages, generateDefaultImages])

  // 计时器
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null

    if (isGameStarted && !isGameComplete) {
      interval = setInterval(() => {
        setTimer((prev) => prev + 1)
      }, 1000)
    }

    return () => {
      if (interval) clearInterval(interval)
    }
  }, [isGameStarted, isGameComplete])

  // 洗牌算法
  const shuffleCards = (cardsToShuffle: Card[]): Card[] => {
    const shuffled = [...cardsToShuffle]

    // Fisher-Yates 洗牌算法
    for (let i = shuffled.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1))
      ;[shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]]
    }

    return shuffled
  }

  // 处理卡片点击
  const handleCardClick = (id: number) => {
    // 首次点击时开始游戏
    if (!isGameStarted) {
      setIsGameStarted(true)
    }

    // 如果游戏结束或卡片已翻开/已匹配或已有两张卡片翻开，则忽略点击
    const clickedCard = cards.find((card) => card.id === id)
    if (isGameComplete || !clickedCard || clickedCard.isFlipped || clickedCard.isMatched || flippedCards.length >= 2) {
      return
    }

    // 翻开卡片
    const updatedCards = cards.map((card) => (card.id === id ? { ...card, isFlipped: true } : card))

    setCards(updatedCards)

    // 添加到已翻开卡片
    const newFlippedCards = [...flippedCards, id]
    setFlippedCards(newFlippedCards)

    // 如果已翻开两张卡片，检查是否匹配
    if (newFlippedCards.length === 2) {
      setMoves((prev) => prev + 1)

      const firstCard = cards.find((card) => card.id === newFlippedCards[0])
      const secondCard = cards.find((card) => card.id === newFlippedCards[1])

      if (firstCard && secondCard && firstCard.imageUrl === secondCard.imageUrl) {
        // 匹配成功
        setTimeout(() => {
          const matchedCards = cards.map((card) =>
            card.id === firstCard.id || card.id === secondCard.id
              ? { ...card, isMatched: true, isFlipped: false }
              : card,
          )

          setCards(matchedCards)
          setFlippedCards([])

          const newMatchedPairs = matchedPairs + 1
          setMatchedPairs(newMatchedPairs)

          // 检查游戏是否完成
          if (newMatchedPairs === numPairs) {
            setIsGameComplete(true)
            try {
              confetti({
                particleCount: 100,
                spread: 70,
                origin: { y: 0.6 },
              })
            } catch (error) {
              console.error("Confetti error:", error)
            }
          }
        }, 1000)
      } else {
        // 不匹配，翻回卡片
        setTimeout(() => {
          const resetFlippedCards = cards.map((card) =>
            newFlippedCards.includes(card.id) ? { ...card, isFlipped: false } : card,
          )

          setCards(resetFlippedCards)
          setFlippedCards([])
        }, 1000)
      }
    }
  }

  // 格式化时间
  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
  }

  // 重新开始游戏
  const handleRestart = () => {
    // 重置游戏状态
    setFlippedCards([])
    setMatchedPairs(0)
    setMoves(0)
    setTimer(0)
    setIsGameComplete(false)
    setIsGameStarted(false)

    // 重新生成卡片
    let gameImages: string[] = []

    // 如果有上传的图像，使用它们
    if (uploadedImages.length > 0) {
      gameImages = [...uploadedImages]
      // 如果上传的图像不够，用字母图像补充
      if (gameImages.length < numPairs) {
        const defaultImages = generateDefaultImages()
        gameImages = [...gameImages, ...defaultImages.slice(0, numPairs - gameImages.length)]
      }
    } else {
      // 没有上传图像，使用默认字母图像
      gameImages = generateDefaultImages()
    }

    // 限制为所需的对数
    gameImages = gameImages.slice(0, numPairs)

    // 创建卡片
    let cardPairs: Card[] = []
    for (let i = 0; i < numPairs; i++) {
      // 创建一对相同图像的卡片
      cardPairs.push({
        id: i * 2,
        imageUrl: gameImages[i],
        isFlipped: false,
        isMatched: false,
      })

      cardPairs.push({
        id: i * 2 + 1,
        imageUrl: gameImages[i],
        isFlipped: false,
        isMatched: false,
      })
    }

    // 洗牌并设置卡片
    cardPairs = shuffleCards(cardPairs)
    setCards(cardPairs)
  }

  // 计算网格列数
  const getGridColumns = () => {
    if (isMobile) {
      return "grid-cols-4" // 移动设备上始终为 4 列
    }

    switch (difficulty) {
      case "4x2":
        return "grid-cols-4"
      case "6x2":
        return "grid-cols-6"
      case "8x2":
        return "grid-cols-8"
      default:
        return "grid-cols-4"
    }
  }

  if (isLoading) {
    return (
      <div className="w-full flex justify-center items-center py-12">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p>加载游戏中...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="w-full max-w-5xl">
      <div className="flex flex-wrap justify-between items-center mb-6 gap-4">
        <div className="flex items-center gap-4">
          <div className="flex items-center">
            <Trophy className="h-5 w-5 mr-2 text-yellow-500" />
            <span className="font-medium">
              配对: {matchedPairs}/{numPairs}
            </span>
          </div>
          <div className="flex items-center">
            <Timer className="h-5 w-5 mr-2" />
            <span className="font-medium">{formatTime(timer)}</span>
          </div>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={handleRestart}>
            <RotateCcw className="mr-2 h-4 w-4" />
            重新开始
          </Button>
          <Button variant="outline" size="sm" onClick={onReset}>
            新游戏
          </Button>
        </div>
      </div>

      {isGameComplete && (
        <div className="bg-green-100 dark:bg-green-900/30 p-4 rounded-lg mb-6 text-center">
          <h3 className="text-xl font-bold text-green-700 dark:text-green-300 mb-2">恭喜!</h3>
          <p>
            您完成了游戏，用了 {moves} 步和 {formatTime(timer)}!
          </p>
        </div>
      )}

      <div className={`grid ${getGridColumns()} gap-2 sm:gap-4`}>
        {cards.map((card) => (
          <div
            key={card.id}
            className={`aspect-square cursor-pointer transition-all duration-300 transform ${
              card.isFlipped || card.isMatched ? "rotate-y-180" : ""
            }`}
            onClick={() => handleCardClick(card.id)}
          >
            <div className="relative w-full h-full preserve-3d">
              {/* 卡片背面 */}
              <div
                className={`absolute w-full h-full backface-hidden rounded-lg bg-primary/80 flex items-center justify-center ${
                  card.isFlipped || card.isMatched ? "opacity-0" : "opacity-100"
                }`}
              >
                <span className="text-2xl font-bold text-primary-foreground">?</span>
              </div>

              {/* 卡片正面 */}
              <div
                className={`absolute w-full h-full backface-hidden rounded-lg overflow-hidden rotate-y-180 border border-muted ${
                  card.isFlipped || card.isMatched ? "opacity-100" : "opacity-0"
                }`}
              >
                <div className="w-full h-full bg-white flex items-center justify-center">
                  <img src={card.imageUrl || "/placeholder.svg"} alt="卡片" className="w-full h-full object-contain" />
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
