import { GameCard } from "@/components/game-card"

export default function Home() {
  return (
    <div className="container py-8 md:py-12">
      <div className="flex flex-col items-center text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-bold tracking-tight mb-4">欢迎来到网页游戏</h1>
        <p className="text-lg text-muted-foreground max-w-[700px]">
          一系列有趣且互动性强的网页游戏集合。从下方选择一个游戏开始玩吧！
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <GameCard
          title="华容道拼图"
          description="一款滑动拼图游戏，您可以使用自己的图片或从经典图片中选择。"
          imageSrc="/placeholder.svg?height=200&width=400"
          href="/games/klotski"
        />
        <GameCard
          title="记忆配对"
          description="测试您的记忆力，匹配成对的卡片。上传您自己的图片或使用我们的字母卡片。"
          imageSrc="/placeholder.svg?height=200&width=400"
          href="/games/memory"
        />
        <GameCard
          title="2048"
          description="合并相同数字的方块以达到2048。玩经典模式或使用您自己的图片自定义。"
          imageSrc="/placeholder.svg?height=200&width=400"
          href="/games/2048"
        />
        {/* 未来将在此处添加更多游戏卡片 */}
      </div>
    </div>
  )
}
