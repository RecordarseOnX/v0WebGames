"use client"

import { useState } from "react"
import { DifficultySelector } from "@/components/memory/difficulty-selector"
import { ImageUploader } from "@/components/memory/image-uploader"
import { MemoryGame } from "@/components/memory/memory-game"

type Difficulty = "4x2" | "6x2" | "8x2"

export default function MemoryPage() {
  const [difficulty, setDifficulty] = useState<Difficulty | null>(null)
  const [uploadedImages, setUploadedImages] = useState<string[]>([])
  const [gameStarted, setGameStarted] = useState(false)

  const handleReset = () => {
    setDifficulty(null)
    setUploadedImages([])
    setGameStarted(false)
  }

  const getMaxImages = (diff: Difficulty) => {
    switch (diff) {
      case "4x2":
        return 4
      case "6x2":
        return 6
      case "8x2":
        return 8
      default:
        return 4
    }
  }

  return (
    <div className="container py-8">
      <div className="flex flex-col items-center">
        <h1 className="text-3xl md:text-4xl font-bold mb-8 text-center">记忆配对游戏</h1>

        {gameStarted ? (
          <MemoryGame difficulty={difficulty!} uploadedImages={uploadedImages} onReset={handleReset} />
        ) : difficulty ? (
          <ImageUploader
            maxImages={getMaxImages(difficulty)}
            onImagesSelected={setUploadedImages}
            onStart={() => setGameStarted(true)}
            onBack={() => setDifficulty(null)}
            difficulty={difficulty}
          />
        ) : (
          <DifficultySelector onSelect={setDifficulty} />
        )}
      </div>
    </div>
  )
}
