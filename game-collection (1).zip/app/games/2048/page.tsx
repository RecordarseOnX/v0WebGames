"use client"

import { useState } from "react"
import { ModeSelector } from "@/components/2048/mode-selector"
import { ImageUploader } from "@/components/2048/image-uploader"
import { Game2048 } from "@/components/2048/game-2048"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"

type GameMode = "classic" | "custom"

export default function Game2048Page() {
  const [mode, setMode] = useState<GameMode | null>(null)
  const [uploadedImages, setUploadedImages] = useState<string[]>([])
  const [gameStarted, setGameStarted] = useState(false)

  const handleReset = () => {
    setMode(null)
    setUploadedImages([])
    setGameStarted(false)
  }

  const handleBack = () => {
    if (gameStarted) {
      setGameStarted(false)
    } else if (mode) {
      setMode(null)
      setUploadedImages([])
    }
  }

  return (
    <div className="container py-8">
      <div className="flex flex-col items-center">
        <h1 className="text-3xl md:text-4xl font-bold mb-8 text-center">2048 游戏</h1>

        {mode && (
          <div className="w-full max-w-5xl mb-6">
            <Button variant="outline" onClick={handleBack}>
              <ArrowLeft className="mr-2 h-4 w-4" />
              {gameStarted ? "返回设置" : "更改模式"}
            </Button>
          </div>
        )}

        {gameStarted ? (
          <Game2048 mode={mode!} customImages={uploadedImages} onReset={handleReset} />
        ) : mode === "custom" ? (
          <ImageUploader
            onImagesSelected={setUploadedImages}
            onStart={() => setGameStarted(true)}
            uploadedImages={uploadedImages}
          />
        ) : mode === "classic" ? (
          <div className="w-full max-w-md text-center">
            <p className="mb-6 text-muted-foreground">
              玩经典的2048游戏。合并相同数字的方块以创建一个数值为两者之和的方块。
            </p>
            <Button onClick={() => setGameStarted(true)}>开始游戏</Button>
          </div>
        ) : (
          <ModeSelector onSelect={setMode} />
        )}
      </div>
    </div>
  )
}
