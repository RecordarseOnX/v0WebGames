"use client"

import { useState } from "react"
import { ImageSelector } from "@/components/klotski/image-selector"
import { DifficultySelector } from "@/components/klotski/difficulty-selector"
import { KlotskiGame } from "@/components/klotski/klotski-game"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"

type Difficulty = "3x3" | "4x4" | "5x5"

export default function KlotskiPage() {
  const [selectedImage, setSelectedImage] = useState<string | null>(null)
  const [difficulty, setDifficulty] = useState<Difficulty | null>(null)
  const [gameStarted, setGameStarted] = useState(false)

  const handleReset = () => {
    setSelectedImage(null)
    setDifficulty(null)
    setGameStarted(false)
  }

  return (
    <div className="container py-8">
      <div className="flex flex-col items-center">
        <h1 className="text-3xl md:text-4xl font-bold mb-8 text-center">华容道拼图</h1>

        {gameStarted ? (
          <>
            <div className="w-full max-w-5xl">
              <Button variant="outline" className="mb-4" onClick={handleReset}>
                <ArrowLeft className="mr-2 h-4 w-4" />
                返回设置
              </Button>
              <KlotskiGame imageSrc={selectedImage!} difficulty={difficulty!} />
            </div>
          </>
        ) : selectedImage && difficulty ? (
          <div className="w-full max-w-md flex flex-col items-center">
            <div className="aspect-square w-full relative mb-6">
              <img
                src={selectedImage || "/placeholder.svg"}
                alt="已选择的拼图图片"
                className="w-full h-full object-contain"
              />
            </div>
            <div className="text-center mb-6">
              <p className="text-lg font-medium mb-2">已选择难度: {difficulty}</p>
              <p className="text-muted-foreground">准备开始拼图了吗？</p>
            </div>
            <div className="flex gap-4">
              <Button variant="outline" onClick={handleReset}>
                更改选择
              </Button>
              <Button onClick={() => setGameStarted(true)}>开始游戏</Button>
            </div>
          </div>
        ) : selectedImage ? (
          <DifficultySelector onSelect={setDifficulty} onBack={() => setSelectedImage(null)} />
        ) : (
          <ImageSelector onSelect={setSelectedImage} />
        )}
      </div>
    </div>
  )
}
