// Function to generate a data URL for a number tile
export function generateNumberImage(value: number): string {
  // Check if we're in a browser environment
  if (typeof document === "undefined") {
    return ""
  }

  const canvas = document.createElement("canvas")
  canvas.width = 200
  canvas.height = 200
  const ctx = canvas.getContext("2d")

  if (!ctx) return ""

  // Define colors based on the value
  let backgroundColor
  let textColor

  switch (value) {
    case 2:
      backgroundColor = "#eee4da"
      textColor = "#776e65"
      break
    case 4:
      backgroundColor = "#ede0c8"
      textColor = "#776e65"
      break
    case 8:
      backgroundColor = "#f2b179"
      textColor = "#ffffff"
      break
    case 16:
      backgroundColor = "#f59563"
      textColor = "#ffffff"
      break
    case 32:
      backgroundColor = "#f67c5f"
      textColor = "#ffffff"
      break
    case 64:
      backgroundColor = "#f65e3b"
      textColor = "#ffffff"
      break
    case 128:
      backgroundColor = "#edcf72"
      textColor = "#ffffff"
      break
    case 256:
      backgroundColor = "#edcc61"
      textColor = "#ffffff"
      break
    case 512:
      backgroundColor = "#edc850"
      textColor = "#ffffff"
      break
    case 1024:
      backgroundColor = "#edc53f"
      textColor = "#ffffff"
      break
    case 2048:
      backgroundColor = "#edc22e"
      textColor = "#ffffff"
      break
    default:
      backgroundColor = "#3c3a32"
      textColor = "#ffffff"
  }

  // Background
  ctx.fillStyle = backgroundColor
  ctx.fillRect(0, 0, canvas.width, canvas.height)

  // Number
  ctx.fillStyle = textColor
  ctx.textAlign = "center"
  ctx.textBaseline = "middle"

  // Adjust font size based on number length
  const fontSize = value < 100 ? 80 : value < 1000 ? 65 : 50
  ctx.font = `bold ${fontSize}px Arial`
  ctx.fillText(value.toString(), canvas.width / 2, canvas.height / 2)

  return canvas.toDataURL("image/png")
}
