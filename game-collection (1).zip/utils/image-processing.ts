/**
 * Process an image for the Klotski puzzle game
 * This function ensures the image is properly formatted and visible without cropping
 */
export async function processImage(imageSrc: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const img = new Image()

    img.onload = () => {
      // Create a canvas to process the image
      const canvas = document.createElement("canvas")
      const ctx = canvas.getContext("2d")

      if (!ctx) {
        reject(new Error("Could not get canvas context"))
        return
      }

      // Make a square canvas with padding to fit the entire image
      const maxDimension = Math.max(img.width, img.height)
      const padding = Math.floor(maxDimension * 0.1) // 10% padding

      // Set canvas size to be square with padding
      canvas.width = maxDimension + padding * 2
      canvas.height = maxDimension + padding * 2

      // Fill with white background
      ctx.fillStyle = "white"
      ctx.fillRect(0, 0, canvas.width, canvas.height)

      // Calculate positioning to center the image
      const offsetX = padding + (maxDimension - img.width) / 2
      const offsetY = padding + (maxDimension - img.height) / 2

      // Draw the image centered on the canvas with padding
      ctx.drawImage(img, offsetX, offsetY, img.width, img.height)

      // Convert to data URL
      const dataUrl = canvas.toDataURL("image/png")
      resolve(dataUrl)
    }

    img.onerror = () => {
      reject(new Error("Failed to load image"))
    }

    // Set crossOrigin to avoid CORS issues
    img.crossOrigin = "anonymous"
    img.src = imageSrc
  })
}
