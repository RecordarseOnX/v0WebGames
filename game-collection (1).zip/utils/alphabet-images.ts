// Alphabet images for the memory game
export const alphabetImages = [
  {
    letter: "A",
    color: "#FF5252",
    id: "a",
  },
  {
    letter: "B",
    color: "#FF9800",
    id: "b",
  },
  {
    letter: "C",
    color: "#FFEB3B",
    id: "c",
  },
  {
    letter: "D",
    color: "#4CAF50",
    id: "d",
  },
  {
    letter: "E",
    color: "#2196F3",
    id: "e",
  },
  {
    letter: "F",
    color: "#9C27B0",
    id: "f",
  },
  {
    letter: "G",
    color: "#E91E63",
    id: "g",
  },
  {
    letter: "H",
    color: "#00BCD4",
    id: "h",
  },
  {
    letter: "I",
    color: "#795548",
    id: "i",
  },
  {
    letter: "J",
    color: "#607D8B",
    id: "j",
  },
  {
    letter: "K",
    color: "#F44336",
    id: "k",
  },
  {
    letter: "L",
    color: "#FFC107",
    id: "l",
  },
  {
    letter: "M",
    color: "#8BC34A",
    id: "m",
  },
  {
    letter: "N",
    color: "#3F51B5",
    id: "n",
  },
  {
    letter: "O",
    color: "#673AB7",
    id: "o",
  },
  {
    letter: "P",
    color: "#009688",
    id: "p",
  },
]

// Function to generate a data URL for a letter card
export function generateLetterImage(letter: string, color: string): string {
  // Check if we're in a browser environment
  if (typeof document === "undefined") {
    return ""
  }

  const canvas = document.createElement("canvas")
  canvas.width = 200
  canvas.height = 200
  const ctx = canvas.getContext("2d")

  if (!ctx) return ""

  // Background
  ctx.fillStyle = color
  ctx.fillRect(0, 0, canvas.width, canvas.height)

  // Letter
  ctx.fillStyle = "white"
  ctx.font = "bold 120px Arial"
  ctx.textAlign = "center"
  ctx.textBaseline = "middle"
  ctx.fillText(letter, canvas.width / 2, canvas.height / 2)

  // Add a border
  ctx.strokeStyle = "rgba(0,0,0,0.2)"
  ctx.lineWidth = 4
  ctx.strokeRect(0, 0, canvas.width, canvas.height)

  return canvas.toDataURL("image/png")
}
